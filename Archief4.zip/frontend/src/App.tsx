import * as React from "react";
import { Form, Table } from "./movies";

import "./App.css";

function App() {
  return (
    <div>
      <Form />
      <Table />
    </div>
  );
}

export default App;
