package structs

type Pagination struct {
	Offset int
	Limit  int
}
